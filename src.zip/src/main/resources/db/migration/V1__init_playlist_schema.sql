CREATE TABLE IF NOT EXISTS playlists (
    id BIGSERIAL PRIMARY KEY,
    usuario_id BIGINT NOT NULL,
    nombre VARCHAR(100) NOT NULL,
    descripcion VARCHAR(300),
    visibilidad VARCHAR(20) NOT NULL DEFAULT 'PUBLICA',
    estilo VARCHAR(30) NOT NULL DEFAULT 'URBANO',
    destacada BOOLEAN NOT NULL DEFAULT FALSE,
    fecha_creacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fecha_actualizacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS playlist_prendas (
    playlist_id BIGINT NOT NULL REFERENCES playlists(id) ON DELETE CASCADE,
    prenda_id BIGINT NOT NULL,
    nombre_prenda VARCHAR(150),
    fecha_asociacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS playlist_likes (
    playlist_id BIGINT NOT NULL REFERENCES playlists(id) ON DELETE CASCADE,
    usuario_id BIGINT NOT NULL,
    PRIMARY KEY (playlist_id, usuario_id)
);

CREATE TABLE IF NOT EXISTS playlist_guardados (
    playlist_id BIGINT NOT NULL REFERENCES playlists(id) ON DELETE CASCADE,
    usuario_id BIGINT NOT NULL,
    PRIMARY KEY (playlist_id, usuario_id)
);
